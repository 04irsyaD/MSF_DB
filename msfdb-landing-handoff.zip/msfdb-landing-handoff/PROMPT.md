# Task: Redesign landing page MSF DB (dark theme + toggle bahasa EN/ID)

Kamu bekerja di repo Next.js (App Router) untuk **MSF DB** (https://msf-db.my.id) — tool yang membuat dokumentasi database dari skema SQL memakai AI lokal.

Di folder ini ada:
- `page.reference.tsx` — implementasi landing page yang sudah jadi dan sudah dites. **Jadikan ini acuan utama.**
- `screenshots/00-before-*.png` — tampilan SEKARANG yang rusak.
- `screenshots/01-desktop-en-full.png`, `02-desktop-id-full.png`, `03-mobile-en-full.png`, `04-navbar-lang-switch.png` — tampilan TARGET.

Lihat semua screenshot dulu sebelum mulai.

## Masalah sekarang (lihat 00-before-*.png)
Tema terang dan gelap bercampur: navbar putih tapi teks logo "MSF DB" putih (hilang), judul hero putih di atas gradient yang memudar ke putih, badge/pill nyaris tidak terbaca, kartu fitur gelap di atas section abu-abu, tombol hijau pakai teks putih (kontras rendah). Kemungkinan penyebab: `globals.css` bawaan create-next-app (`--background`/`--foreground` + `@media (prefers-color-scheme: dark)`) bentrok dengan class warna di komponen.

## Yang harus dikerjakan
1. **Eksplorasi dulu**: cek struktur repo, file landing page sekarang (biasanya `app/page.tsx` atau `src/app/page.tsx`), `app/layout.tsx`, `globals.css`, `tailwind.config.*`, versi Tailwind (v3 atau v4), dan apakah `lucide-react` sudah terpasang. Laporkan singkat temuanmu sebelum mengubah apa pun.
2. **Ganti landing page** dengan isi `page.reference.tsx`. Sesuaikan dengan repo:
   - `APP_URL` (sekarang `/dashboard`) → arahkan ke route workspace/dashboard yang benar di repo ini.
   - Kalau repo sudah punya komponen Logo/Button/Navbar sendiri, boleh dipakai selama hasil visualnya sama dengan screenshot target.
   - Kalau `lucide-react` belum ada, install.
3. **Perbaiki `globals.css`**: hapus/nonaktifkan blok `@media (prefers-color-scheme: dark)` dan `body { background: var(--background); color: var(--foreground) }` yang bikin tema campur. Set `html { scroll-behavior: smooth }` dan background body `#020617` (slate-950) supaya tidak ada kilatan putih.
   - Pastikan perubahan ini **tidak merusak halaman lain** (dashboard/workspace). Cek halaman lain yang memakai variabel itu; kalau dipakai, jangan dihapus — cukup pastikan landing page tidak bergantung padanya.
4. **Font**: pakai Inter (sans) dan JetBrains Mono (mono) via `next/font/google` di `app/layout.tsx`, lalu hubungkan ke `fontFamily.sans` / `fontFamily.mono` di Tailwind (v3: `tailwind.config`; v4: `@theme` di CSS).
5. **Bahasa**: default **English**. Toggle EN/ID di navbar (lihat `04-navbar-lang-switch.png`). Pilihan disimpan di `localStorage` key `msfdb-lang` dan `document.documentElement.lang` ikut berubah. Semua copy ada di objek `dict` — jangan hardcode teks di JSX. Set `<html lang="en">` di layout.
6. **Metadata** di `layout.tsx`: title `MSF DB — AI Database Documentation`, description dalam bahasa Inggris.

## Aturan desain (jangan dilanggar)
- Satu tema gelap, warna ditulis eksplisit: background `slate-950`, card `slate-900`/`slate-950`, border `slate-800`, heading `slate-50`, body `slate-400`, meta `slate-500`.
- Aksen `emerald`: tombol utama `bg-emerald-500 text-slate-950` (**teks gelap, bukan putih**), teks aksen `emerald-400`.
- Struktur pakai garis tipis (border), bukan bayangan. Satu-satunya shadow di jendela preview produk.
- Label/eyebrow, kode, chip teknologi pakai font mono.
- Tidak ada gradient biru-ungu, emoji, atau kartu dengan border kiri tebal.
- Responsif: tanpa scroll horizontal di lebar 375px; di mobile tombol "Open Workspace" navbar disembunyikan, toggle EN/ID tetap tampil.

## Definition of done
- `npm run build` (dan `npm run lint` kalau ada) lolos tanpa error.
- Jalankan dev server dan cek: desktop 1366px dan mobile 375px cocok dengan screenshot target; klik ID → semua teks berganti; reload → tetap ID; link navbar scroll ke `#features`, `#how-it-works`, `#tech`; tombol CTA menuju route workspace yang benar.
- Halaman selain landing tidak berubah tampilannya.
- Akhiri dengan ringkasan file yang diubah. Jangan commit/push kecuali saya minta.
